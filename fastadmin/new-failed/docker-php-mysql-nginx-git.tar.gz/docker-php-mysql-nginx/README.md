docker-compose nginx mysql56 php72 -d

启动环境就这么简单

# composer使用
docker-compose run composer bash

> 如果提示proc_open(): fork failed - Out of memory 使用下面代替 然后使用国内镜像 在进行安装

```
docker run -it --rm -v $PWD:/app --privileged=true composer /bin/bash

composer config -g repo.packagist composer https://mirrors.aliyun.com/composer/

dd if=/dev/zero of=/var/swap.1 bs=1M count=1024
mkswap /var/swap.1
swapon /var/swap.1
```

# node使用
docker-compose run node bash